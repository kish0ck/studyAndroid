// 주석 작성하는 방법
// 주석 -> 사람만 보기 위해서 작성한다.

// 1. var 변수 선언하기
var changeYes = 100

/*
var changeYes // 선언과 동시에 초기화를 시켜줘야 한다
changeYes = 100
*/
println(changeYes)
changeYes = 200
println(changeYes)


// 2. val 변수 선언하기

val CHANGE_NO = 100
println(CHANGE_NO)
//change_no = 200

val SCHOOL_NAME = "대한민국 학교"
println(SCHOOL_NAME)
